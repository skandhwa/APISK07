package PayloadData;

public class Payload {
	
	
	public static String addEmployeeDetails(String empName,String jobRole)
	{
		
		String emp="{\r\n"
				+ "    \"name\": \""+empName+"\",\r\n"
				+ "    \"job\": \""+jobRole+"\"\r\n"
				+ "}";
		
		return emp;
		
		
		
		
	}
	
	public static String bookDetails(String isbn,String aisle,String author)
	{
		String bookData="{\r\n"
				+ "\r\n"
				+ "\"name\":\"Learn Appium Automation with Java\",\r\n"
				+ "\"isbn\":\""+isbn+"\",\r\n"
				+ "\"aisle\":\""+aisle+"\",\r\n"
				+ "\"author\":\""+author+"\"\r\n"
				+ "}";
		
		return bookData;
	}
	
	
	
	
	
	
	

}
