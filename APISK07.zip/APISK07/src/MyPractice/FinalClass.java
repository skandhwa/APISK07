package MyPractice;

final class V1
{
	void display()
	{
		System.out.println("hello");
	}
}

class V2 extends V1
{
	void test()
	{
		System.out.println("hi");
	}
}




public class FinalClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
