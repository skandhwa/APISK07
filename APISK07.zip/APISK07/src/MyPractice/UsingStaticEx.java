package MyPractice;

class Employees
{
	int id;
	static String comname="TCS";
	String empname;
	
	Employees(int i,String n)
	{
		id=i;
		empname=n;
	}
	
	static void change()
	{
		comname="Infosys";
	}
	
	
	
	void display()
	{
		System.out.println(id+"  "+comname+"  "+empname);
	}
	
	
}

public class UsingStaticEx {

	public static void main(String[] args) {
		
		Employees.change();
		
		Employees obj=new Employees(1234,"Manish");
		obj.display();
		
		Employees obj1=new Employees(9234,"Ramesh");
		obj1.display();
		
		Employees obj2=new Employees(9876,"Harish");
		obj2.display();
		

	}

}
