package MyPractice;

class Employees2
{
	int id;
	String name;
	boolean isMarried;
	float salary;
	
	Employees2(int id,String name,boolean isMarried)
	{
		this.id=id;
		this.name=name;
		this.isMarried=isMarried;
	}
	
	Employees2(int id,String name,boolean isMarried,float salary)
	{
		this(id,name,isMarried);
		this.salary=salary;
	}
	
}



public class ThisEx2 {

	public static void main(String[] args) {
		
		
		
		

	}

}
