package MyPractice;

class Test2
{
	static void display()
	{
		System.out.println("Hello");
	}
}



public class StaticMethodsEx {

	public static void main(String[] args) {
		
		Test2.display();

	}

}
