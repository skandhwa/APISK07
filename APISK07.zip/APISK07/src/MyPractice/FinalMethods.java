package MyPractice;

class Bank
{
	final int getROI(int x,int y)
	{
		return x+y;
	}
}

class SBI extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}

class HDFC extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}


public class FinalMethods {

	public static void main(String[] args) {
		

	}

}
