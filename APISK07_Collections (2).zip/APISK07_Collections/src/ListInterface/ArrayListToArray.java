package ListInterface;

import java.util.ArrayList;
import java.util.List;

public class ArrayListToArray {

	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<Integer>();
		
		li.add(34);
		li.add(56);
		li.add(97);
		li.add(97);
		li.add(null);
		li.add(null);
		
		Object[] arr=li.toArray();
		
		for(Object x:arr)
		{
			System.out.println(x);
		}
		
		
		

	}

}
