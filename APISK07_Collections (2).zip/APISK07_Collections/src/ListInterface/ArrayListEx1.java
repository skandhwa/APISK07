package ListInterface;

import java.util.ArrayList;
import java.util.Arrays;

public class ArrayListEx1 {

	public static void main(String[] args) {
		 String[] a = {"O","R","R","O","R","O"};

	       
	        ArrayList<String> nonZeroList = new ArrayList<>();
	        ArrayList<String> zeroList = new ArrayList<>();

	        // Separate non-zeros and zeros
	        for (String ball : a) {
	            if (ball.equalsIgnoreCase("O")) {
	                zeroList.add(ball);
	            } else {
	                nonZeroList.add(ball);
	            }
	        }

	        
	        nonZeroList.addAll(zeroList);

	        // Display result
	        System.out.println("Original array: " + Arrays.toString(a));
	        System.out.println("After moving zeros to right: " + nonZeroList);

	}

}
