package ListInterface;

import java.util.Stack;

public class StackEx1 {

	public static void main(String[] args) {
		
		Stack<Integer> s1=new Stack<Integer>();
		s1.push(56);
		s1.push(99);
		s1.push(102);
		s1.push(87);
		
		System.out.println(s1);
		
		s1.pop();
		
		System.out.println("After popping elements are  "+s1);
		
		s1.push(105);
		s1.push(79);
		s1.pop();
		
		System.out.println("After popping elements are  "+s1);
		
		s1.remove(2);

	}

}
