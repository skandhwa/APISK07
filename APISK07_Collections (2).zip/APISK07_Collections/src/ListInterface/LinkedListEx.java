package ListInterface;

import java.util.LinkedList;
import java.util.Vector;

public class LinkedListEx {

	public static void main(String[] args) {
		
		
		LinkedList<Integer> li=new LinkedList<Integer>();
		li.add(67);
		li.add(99);
		li.add(102);
		li.add(89);
		
		for(Integer x:li)
		{
			System.out.println(x);
		}
		
		
		
		
		Vector<Integer> v=new Vector<Integer>();
		v.add(67);
		v.add(99);
		v.add(102);
		v.add(89);
		
		for(Integer x:v)
		{
			System.out.println(x);
		}
		

	}

}
