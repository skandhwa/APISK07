package MapInterface;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class MapEx2 {

	public static void main(String[] args) {
		
		Map<Integer,Integer> mp=new LinkedHashMap<Integer,Integer>();
		
		mp.put(12,23);
		mp.put(34,33);
		mp.put(56,43);
		mp.put(78,53);
		mp.put(88,63);
		
	boolean flag=	mp.containsKey(12);
	System.out.println("Does the map contains 12 "+flag);
	
	boolean flag1=	mp.containsValue(63);
	System.out.println("Does the map contains 63 as value "+flag1);
	
	Map<Integer,Integer> mp2=new LinkedHashMap<Integer,Integer>();
	
	mp2.put(12,123);
	mp2.put(64,33);
	mp2.put(96,43);
	mp2.put(68,53);
	mp2.put(84,63);
	
	System.out.println("After merging the map is ");
	mp.putAll(mp2);
	System.out.println(mp);
	
	Set<Integer> s2=mp.keySet();
	
	mp.replace(34, 88);
	
	
	
	
	
	
	
		
		
		

	}

}
