package MapInterface;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyOfWords {

	public static void main(String[] args) {
		
		String str="Tip Tap Tip Toe Tip Tap";
		Map<String,Integer> mp=new LinkedHashMap<String,Integer>();
		
		String []s=str.split(" ");
		
		for(String x:s)
		{
			if(mp.containsKey(x))
			{
				mp.put(x, (mp.get(x)+1));
			}
			
			else
			{
				mp.put(x,1);
			}
		}
		
		for(Map.Entry y:mp.entrySet())
		{
			System.out.print(y.getKey()+" ");
			System.out.println(y.getValue());
		}
		
		
		int maxFreq=0;
		int minFreq=99999;
		String maxString=null;
		String minString=null;
		
		for(Map.Entry<String,Integer> x:mp.entrySet() )
		{
			int freq=x.getValue();
			String element=x.getKey();
			if(freq>maxFreq)
			{
				maxFreq=freq;
				maxString=element;
				
			}
			
			if(freq<minFreq)
			{
				minFreq=freq;
				minString=element;
				
			}
			
		}
		
		
		System.out.println("MaximumFrequency is "+maxString  +" -> "+maxFreq);
		System.out.println("MinimumFrequency is "+minString  +" -> "+minFreq);
		
		
		
		
		
		

	}

}
