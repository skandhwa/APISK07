package MapInterface;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class MapEx1 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new LinkedHashMap<Integer,String>();
		mp.put(23,"apple");
		mp.put(45,"banana");
		mp.put(67, "orange");
		mp.put(67, "kiwi");
		mp.put(null, null);
		mp.put(98, null);
		mp.put(null,"pines");
		
		
		System.out.println(mp);
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+" ");
			System.out.println(x.getValue());
			
			
		}
		
		
		

	}

}
