package MapInterface;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyOfString {

	public static void main(String[] args) {
		
		String str="RRadar";
		str=str.toLowerCase();
		Map<Character,Integer> mp=new LinkedHashMap<Character,Integer>();
		
		char []ch=str.toCharArray();
		
		for(char c:ch)
		{
			if(mp.containsKey(c))
			{
				mp.put(c, (mp.get(c)+1));///mp.put(r,2)
			}
			else
			{
				mp.put(c,1);
			}
			
		}
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+"   ");
			System.out.println(x.getValue());
		}
		
		
		int maxFreq=0;
		int minFreq=99999;
		char maxChar='\0';
		char minChar='\0';
		
		for(Map.Entry<Character,Integer> x:mp.entrySet() )
		{
			int freq=x.getValue();///freq=3///freq=2///freq=1
			char element=x.getKey();////element=r/////element=a//element=d
			if(freq>maxFreq)////3>0///2>3///1>3
			{
				maxFreq=freq;///maxFreq=3///maxFreq=3
				maxChar=element;///maxChar=r
				
			}
			
			if(freq<minFreq)////3<99999///2<3///1<2
			{
				minFreq=freq;//minFreq=3///minFreq=2//minFreq=1
				minChar=element;////minchar=r////minchar=a//minchar=d
				
			}
			
		}
		
		
		System.out.println("MaximumFrequency is "+maxChar  +" -> "+maxFreq);
		System.out.println("MinimumFrequency is "+minChar  +" -> "+minFreq);
		
		
		
		
		
		
		
		

	}

}
