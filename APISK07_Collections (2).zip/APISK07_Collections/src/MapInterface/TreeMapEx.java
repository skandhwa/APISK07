package MapInterface;

import java.util.TreeMap;

public class TreeMapEx {

	public static void main(String[] args) {
		
		TreeMap<Integer,String> mp=new TreeMap<Integer,String>();
		
		mp.put(12,"apple");
		mp.put(4,"banana");
		mp.put(2,"kiwi");
		mp.put(16,"melon");
		
		System.out.println(mp);
		
		
		

	}

}
