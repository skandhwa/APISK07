package MapInterface;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyofArray {

	public static void main(String[] args) {
		
		int []a= {20,10,10,40,20,10,10,40,20};
		int n=a.length;
		
		Map<Integer,Integer> mp=new LinkedHashMap<Integer,Integer>();
		
		for(int i=0;i<n;i++)//i=0,0<8//i=1,1<8//i=2,2<8
		{
			if(mp.containsKey(a[i]))//
			{
				mp.put(a[i],  (mp.get(a[i])+1) );
			}
			else
			{
				mp.put(a[i],1);
			}
		}
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+" ");
			System.out.println(x.getValue());
			
			
		}
		
		int maxFreq=0;
		int minFreq=99999;
		
		int maxElement=0,minElement=0;
		
		
		for(Map.Entry<Integer,Integer> x:mp.entrySet() )
		{
			int freq=x.getValue();///freq=4///freq=2
			int element=x.getKey();//element=10//element=40
			if(freq>maxFreq)///
			{
				maxFreq=freq;///maxFreq=3//maxFreq=4
				maxElement=element;///maxElement=20///maxElement=10
				
			}
			
			if(freq<minFreq)////4<3///2<3
			{
				minFreq=freq;///minFreq=3///minFreq=2
				minElement=element;///minElement=20///minElement=40
				
			}
			
		}
		
		
		System.out.println("MaximumFrequency is "+maxElement  +" -> "+maxFreq);
		System.out.println("MinimumFrequency is "+minElement  +" -> "+minFreq);
		
		
		
		
		
		
		
		
		
		

	}

}
