package SetInterface;

public class SetEx7 {

	public static void main(String[] args) {
		
		
		
		

	}

}
