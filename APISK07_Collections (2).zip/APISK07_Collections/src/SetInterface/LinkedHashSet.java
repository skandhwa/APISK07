package SetInterface;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashSet {

	public static void main(String[] args) {
		
		
		Set<Integer> s1=new LinkedHashSet<Integer>();
		
		s1.add(34);
		s1.add(89);
		s1.add(105);
		s1.add(87);
		s1.add(89);
		
		
		for(int x:s1)
		{
			System.out.println(x);
		}
		
		

	}

}
