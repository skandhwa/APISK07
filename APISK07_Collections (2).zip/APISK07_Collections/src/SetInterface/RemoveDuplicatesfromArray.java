package SetInterface;

import java.util.HashSet;
import java.util.Set;

public class RemoveDuplicatesfromArray {

	public static void main(String[] args) {
		
		int []a= {2,1,1,4,2,1,1,4};
		Set<Integer> s1=new HashSet<Integer>();
		
		for(int x:a)
		{
			System.out.print(x+" ");
		}
		
		System.out.println("Removing duplicates");
		
		for(int y:a)
		{
			s1.add(y);
		}
		
		System.out.print(s1);
		
		
		
		

	}

}
