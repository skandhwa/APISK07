package Authentications;

import static io.restassured.RestAssured.given;

import java.util.LinkedHashMap;
import java.util.Map;

import io.restassured.RestAssured;

public class BearerTokenAuth {

	public static void main(String[] args) {
		
		String BearerToken="Bearer a682a89b74963538f47d3ec72b6af8f655ef7c20f8d1a7e3ad8582ffd8dfdf64";
		
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		mp.put("name", "Harry");
		
		mp.put("gender", "male");
		mp.put("email", "abcg87689@gmail.com");
		mp.put("status", "active");
		
		RestAssured.baseURI="https://gorest.co.in";
		String Response=		given().log().all().headers("content-Type","application/json")
				.headers("Authorization",BearerToken)
				.body(mp)
				.when().post("public/v2/users")
				.then().assertThat().statusCode(201)
				.extract().response().asString();
		
		System.out.println(Response);

		

	}

}
