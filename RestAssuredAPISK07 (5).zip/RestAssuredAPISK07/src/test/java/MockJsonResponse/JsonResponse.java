package MockJsonResponse;

public class JsonResponse {
	
	public static String MockJsonResponse()
	{
		String responsePayload=
		"{\r\n"
		+ "\r\n"
		+ "\"dashboard\": {\r\n"
		+ "\r\n"
		+ "\"purchaseAmount\": 1200,\r\n"
		+ "\r\n"
		+ "\"website\": \"grotechminds.com\"\r\n"
		+ "\r\n"
		+ "},\r\n"
		+ "\r\n"
		+ "\"courses\": [\r\n"
		+ "\r\n"
		+ "{\r\n"
		+ "\r\n"
		+ "\"title\": \"Selenium Python\",\r\n"
		+ "\r\n"
		+ "\"price\": 100,\r\n"
		+ "\r\n"
		+ "\"copies\": 3\r\n"
		+ "\r\n"
		+ "},\r\n"
		+ "\r\n"
		+ "{\r\n"
		+ "\r\n"
		+ "\"title\": \"Cypress\",\r\n"
		+ "\r\n"
		+ "\"price\": 200,\r\n"
		+ "\r\n"
		+ "\"copies\": 2\r\n"
		+ "\r\n"
		+ "},\r\n"
		+ "\r\n"
		+ "{\r\n"
		+ "\r\n"
		+ "\"title\": \"RPA\",\r\n"
		+ "\r\n"
		+ "\"price\": 500,\r\n"
		+ "\r\n"
		+ "\"copies\": 1\r\n"
		+ "\r\n"
		+ "}\r\n"
		+ "\r\n"
		+ "]\r\n"
		+ "\r\n"
		+ "}";
		
		return responsePayload;
		
		
	}
	
	
	

}
