package MISC;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import PayloadData.Payload;

import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;
import io.restassured.filter.session.SessionFilter;

public class SessionFilterEx {

	SessionFilter s;
	
	@BeforeTest
	public SessionFilter captureSessionId()
	{
		s=new SessionFilter();
		return s;
	}
	
	@Test
	public void myTest1()
	{
		RestAssured.baseURI="https://httpbin.org";
	String Response=	given().log().all().relaxedHTTPSValidation().filter(s)
		.when().get("get").then().extract().response().asString();
	
	System.out.println(Response);
		
	}
	
	@Test
	public void myTest2()
	{
		RestAssured.baseURI="https://httpbin.org";
		String Response=	given().log().all().relaxedHTTPSValidation().filter(s).
				body(Payload.addEmployeeDetails("Saurabh","ITA"))
			.when().post("post").then().extract().response().asString();
		
		System.out.println(Response);
	}
	
	
	
	
	
	

}
