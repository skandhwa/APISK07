package MISC;

import io.restassured.RestAssured;
import static org.hamcrest.Matchers.*;
import static io.restassured.RestAssured.*;

public class UsingHamcrestMatcher {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://jsonplaceholder.typicode.com/";
		
	String Response=	given().log().all().when().get("posts/1")
		.then().
		body("userId",equalTo(1))
		.body("title",notNullValue()).
		body("userId",is(1)).
		body("userId",not(2))
		.body("title",startsWith("sun"))
		.body("title",endsWith("rit"))
		.body("userId", greaterThan(0))
		.body("id",lessThan(10)).
		
		
		
		
		
		extract().response().asString();
	
	
	System.out.println(Response);
		
		

	}

}
