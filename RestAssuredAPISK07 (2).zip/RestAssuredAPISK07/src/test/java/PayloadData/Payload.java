package PayloadData;

public class Payload {
	
	
	public static String addEmployeeDetails(String empName,String jobRole)
	{
		
		String emp="{\r\n"
				+ "    \"name\": \""+empName+"\",\r\n"
				+ "    \"job\": \""+jobRole+"\"\r\n"
				+ "}";
		
		return emp;
		
		
		
		
	}
	
	
	
	
	

}
