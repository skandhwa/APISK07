package POJOEx5;

public class EmployeeAddress5 {
	
	private HouseDetailsPOJO hdpojo;
	private int zip;
	private String city;
	private String state;
	
	public HouseDetailsPOJO getHdpojo() {
		return hdpojo;
	}
	public void setHdpojo(HouseDetailsPOJO hdpojo) {
		this.hdpojo = hdpojo;
	}
	public int getZip() {
		return zip;
	}
	public void setZip(int zip) {
		this.zip = zip;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	
	

}
