package HandlingDBConnection;

import static io.restassured.RestAssured.given;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

import io.restassured.RestAssured;

public class CreateEmployee {

	public static void main(String[] args) throws SQLException {
		
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		mp.put("id",CreateConnection.DbConnection(1));
		mp.put("name",CreateConnection.DbConnection(2));
		mp.put("salary",CreateConnection.DbConnection(3));
		mp.put("hiredate",CreateConnection.DbConnection(4));
		mp.put("address",CreateConnection.DbConnection(5));
		
		RestAssured.baseURI="https://reqres.in";
		
		String Response=		given().log().all().headers("x-api-key","reqres-free-v1").
				headers("content-type","application/json").
				body(mp)
				.when().post("api/users")
				.then().log().all().assertThat().statusCode(201)
				.extract().response().asString();


		System.out.println(Response);
		
		
		
		

	}

}
