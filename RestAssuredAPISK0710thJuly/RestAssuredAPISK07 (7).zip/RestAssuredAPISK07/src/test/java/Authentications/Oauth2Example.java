package Authentications;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class Oauth2Example {
	
	String client_id="ASyStlg4z4BjlmHNrXnDSLwFzY6j8NwPPE16opmTNUxHYf1IXRThQgb3ZN9uWeq3byeJPHlGXp_Gk2f7";
	String client_secret_id="ECKYHfIutJTW9x6PgRFePjsHJPH5MAomf34tbLqp7xmeckGaZGwM083k7ZHrY1cSnW18IYZcNKOH_chu";
	
	String access_token;
	@Test(priority=1)
	public void getAccessToken() throws InterruptedException
	{
		RestAssured.baseURI="https://api-m.sandbox.paypal.com";
		
	String Response=	given().log().all().auth().preemptive().basic(client_id, client_secret_id)
		.param("grant_type","client_credentials")
		.when().post("v1/oauth2/token")
		.then().log().all().extract().response().asString();
	
	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
	
	access_token=js.getString("access_token");
	
	System.out.println();
	System.out.println();
	System.out.println();
	System.out.println();
	System.out.println();
	Thread.sleep(3000);
	
	}
	
	
	
	@Test(priority=2)
	public void getResponse()
	{
		RestAssured.baseURI="https://api-m.sandbox.paypal.com";
	String ResponseData=	given().log().all().
		queryParam("page",3)
		.queryParam("page_size",4)
		.queryParam("total_count_required", true)
		.auth().oauth2(access_token)
		.when().get("v1/invoicing/invoices")
		.then().extract().response().asString();
		
		System.out.println("The response from Resource server is  "+ResponseData);
		
		
		
		
	}
	
	
	
	
	

}
