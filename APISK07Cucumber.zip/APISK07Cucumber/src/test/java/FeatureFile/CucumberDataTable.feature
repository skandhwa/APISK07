@sanity

Feature: Add details to demo application

  Scenario: Add details to register form
    Given user opens the demo application
    And user enters the below details
      | firstname | lastname | address   | emailaddress  |
      | saurabh   | kandhway | hyderabad | abc@gmail.com |
