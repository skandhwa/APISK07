@smoke

Feature: Validate Login Functionality with parameterization


@sanity
  Scenario Outline: Validate User ID and password
    Given user open the application
    And user enters the username as "<username>"
    And user enters the password as "<password>"
    When user clicks on the submit button
    Then user will be navigated to home page of the application

    Examples: 
      | username | password  |
      | skandhwa | Test@1234 |
    # | gst567tes | Test@99   |
    # | gaurav456 | Test@9iuu |

  @smoke  
    Scenario Outline: Validate User ID and password
    Given user open the application
    And user enters the username as "<username>"
    And user enters the password as "<password>"
    When user clicks on the submit button
    Then user will be navigated to home page of the application

    Examples: 
      | username | password  |
      | skandhwa | Test@1234 |
    # | gst567tes | Test@99   |
    # | gaurav456 | Test@9iuu |
    