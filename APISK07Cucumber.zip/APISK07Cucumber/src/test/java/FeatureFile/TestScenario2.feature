@sanity

Feature: Validate Login functionality of application 

Background: 


Given user logins to the facebook application
And user enters username 
And user enters password
When user clicks on submit button
Then user will be navigated to home page of application


@sanity
Scenario: Validate login Functionality with correct user id and password



And user will verify the page title


Scenario: Find friend list in Facebook


And user will click on Friends link in Facebook 
And user will verify the page title



Scenario: Navigate to marketplace


And user clicks on the marketplace link
And user adds one item from FB marketplace



