@smoke

Feature: Validate Login functionality of application 

Scenario: Validate login Functionality with correct user id and password


Given user logins to the facebook application
And user enters username 
And user enters password
When user clicks on submit button
Then user will be navigated to home page of application
When user clicks on the submit button
#Then capture the screenshot of the page








