package StepDefintion8;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions
(
		features="src/test/java/FeatureFile/",
		glue= {"StepDefintion8"},
		tags="@sanity and not @smoke",
		dryRun=false,
		monochrome=false,
		plugin= {"pretty","html:target/HtmlReports/index.html"}
		
		
		
		
		
		
		)












public class TestRunner {

}
