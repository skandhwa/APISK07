package StepDefintion8;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition8 {
	
	
	@Before
	public void beforeTest()
	{
		System.out.println("I am before test");
	}
	
	@After
	public void afterTest()
	{
		System.out.println("I am after test");
	}
	
	@Before("@sanity")
	public void beforeTest1()
	{
		System.out.println("I am before Test1");
	}
	
	@After("@sanity")
	public void beforeTest2()
	{
		System.out.println("I am after Test1");
	}
	
	
	@Given("user opens the demo application")
	public void user_opens_the_demo_application() {
	    
	}

	@Given("user enters the below details")
	public void user_enters_the_below_details(io.cucumber.datatable.DataTable userdetails) throws InterruptedException 
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		List<List<String>> data=userdetails.asLists(String.class);
		driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(data.get(1).get(0));
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(data.get(1).get(1));
		driver.findElement(By.xpath("//textarea[@rows=3]")).sendKeys(data.get(1).get(2));
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys(data.get(1).get(3));
		
		
		
	   
	}

	
	
	
	
	
	@Given("user logins to the facebook application")
	public void user_logins_to_the_facebook_application() {
	    
	}

	@Given("user enters username")
	public void user_enters_username() {
		
		System.out.println("username enetered");
	    
	}

	@Given("user enters password")
	public void user_enters_password() {
		System.out.println("password enetered");
	    
	}

	@When("user clicks on submit button")
	public void user_clicks_on_submit_button() {
		
		System.out.println("submit clicked");
	    
	}

	@Then("user will be navigated to home page of application")
	public void user_will_be_navigated_to_home_page_of_application() {
	    
	}
	
	
	
	@Given("user open the application")
	public void user_open_the_application() {
	   
	}

	@Given("user enters the username as {string}")
	public void user_enters_the_username_as(String string) {
	   
	}

	@Given("user enters the password as {string}")
	public void user_enters_the_password_as(String string) {
	   
	}

	@When("user clicks on the submit button")
	public void user_clicks_on_the_submit_button() {
	    
	}

	@Then("user will be navigated to home page of the application")
	public void user_will_be_navigated_to_home_page_of_the_application() {
	   
		System.out.println("Homepage  navigated");
	}
	
	
	@Then("user will click on Friends link in Facebook")
	public void user_will_click_on_friends_link_in_facebook() {
		
		System.out.println("Friend link clicked");
	  
	}

	@Then("user will verify the page title")
	public void user_will_verify_the_page_title() {
		
		System.out.println("pagetitle verified");
	   
	}

	
	@Then("user clicks on the marketplace link")
	public void user_clicks_on_the_marketplace_link() {
		
		System.out.println("marketplace link clicked");
	    
	}

	@Then("user adds one item from FB marketplace")
	public void user_adds_one_item_from_fb_marketplace() {
		
		System.out.println("item added");
	   
	}


}
