package ListInterface;

import java.util.ArrayList;
import java.util.ListIterator;

public class ListInteratorEx {

	public static void main(String[] args) {
		ArrayList<String> fruits = new ArrayList<>();
        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Cherry");
        fruits.add("Date");

        // Get ListIterator
        ListIterator<String> listIterator = fruits.listIterator();

        // Forward traversal
        System.out.println("Forward Traversal:");
        while (listIterator.hasNext()) {
            String fruit = listIterator.next();
            System.out.println(fruit);

            // Modify element
            if (fruit.contains("Banana")) {
                listIterator.set("Blueberry");
            }
        }

        // Backward traversal
        System.out.println("\nBackward Traversal:");
        while (listIterator.hasPrevious()) {
            System.out.println(listIterator.previous());
        }

        // Final modified list
        System.out.println("\nModified List: " + fruits);

	}

}
