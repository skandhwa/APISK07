package ListInterface;

import java.util.PriorityQueue;
import java.util.Queue;

public class QueueEx {

	public static void main(String[] args) {
		
		Queue<Integer> q=new PriorityQueue<Integer>();
		
		
		q.add(12);
		q.add(45);
		q.add(99);
		q.add(104);
		
		q.remove();
		
		System.out.println(q);
		

	}

}
