package ListInterface;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArryToArrayList {

	public static void main(String[] args) {
		
		Integer []a= {2,4,5,6,9};
		
		List<Integer> li=new ArrayList<>(Arrays.asList(a));
		
		
		
		
		
		

	}

}
