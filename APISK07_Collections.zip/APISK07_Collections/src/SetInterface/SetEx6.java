package SetInterface;

import java.util.HashSet;
import java.util.Set;

public class SetEx6 {

	public static void main(String[] args) {
		Set<Integer> s1=new HashSet<Integer>();
		s1.add(34);
		s1.add(89);
		s1.add(105);
		s1.add(87);
		
		
		Set<Integer> s2=new HashSet<Integer>();
		s2.add(34);
		s2.add(89);
		s2.add(85);
		s2.add(187);
		s2.add(189);
		
		s2.removeAll(s1);
		
		System.out.println(s2);
		

	}

}
