package MyPractice;

public class StringMethods7 {

	public static void main(String[] args) {
		
		
		String str="Hello Gaurabh";
	boolean flag=	str.contains("saurabh");

	System.out.println("Does string contains saurabh "+flag);
	}

}
