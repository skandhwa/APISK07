package MyPractice;

class Test3
{
	public static int LargestSmallest(int []a,int total)
	{
		for(int i=0;i<a.length;i++)///i=1,1<4
		{
			for(int j=i+1;j<a.length;j++)///j=2,2<4
			{
				if(a[i]>a[j])///a[1]>a[2]
				{
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
					
				}
			}
			
			
		}
		
		return a[1];
	}
}






public class ArrayLargestSmallest {

	public static void main(String[] args) {
		
		int[] a = { 4, 9, 12, 2, 6 };
		int x=a.length;
		
	int value=	Test3.LargestSmallest(a, x);
	
	System.out.println("Third largest is  "+value);
		
		

	}

}
