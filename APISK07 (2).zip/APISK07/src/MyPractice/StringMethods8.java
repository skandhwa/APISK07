package MyPractice;

public class StringMethods8 {

	public static void main(String[] args) {
		
		
		String str="Java";
		String str1="ja   va";
		
		
		str1.replace(" ", "");
		
	boolean flag=str.equalsIgnoreCase(str1);
	
	System.out.println("Value is "+flag);

	}

}
