package MyPractice;

public class StringMethods5 {

	public static void main(String[] args) {
		
		
		String str="Hello Saurabh How are you";
		
	int x=	str.indexOf('a',13);
	
	System.out.println("Index of a "+x);
		

	}

}
