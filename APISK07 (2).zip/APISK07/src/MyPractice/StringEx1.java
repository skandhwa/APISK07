package MyPractice;

public class StringEx1 {

	public static void main(String[] args) {
		
		 String str="Hello"; 
		
		
	str=	str.concat("Java");
		
		System.out.println(str);
		
		///String literal 
		
		
		String str1="Hello";
		
		String str3=new String("Saurabh");
		
		

	}

}
