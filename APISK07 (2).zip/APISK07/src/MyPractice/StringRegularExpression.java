package MyPractice;

public class StringRegularExpression {

	public static void main(String[] args) {
		
		
		String str="a%^&*bcd123478()";
		
	str=	str.replaceAll("[a-zA-Z0-9]","");
	System.out.println(str);
		


	}

}
