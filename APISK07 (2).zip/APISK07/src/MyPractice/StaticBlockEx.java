package MyPractice;




public class StaticBlockEx {
	
	static
	{
		System.out.println("Hi");
	}
	

	public static void main(String[] args) {
		
		System.out.println("Hello");

	}

}
