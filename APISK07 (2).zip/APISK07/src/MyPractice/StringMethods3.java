package MyPractice;

public class StringMethods3 {

	public static void main(String[] args) {
		
		
		String str="Indiana";
//	str=	str.substring(3,7);
//	System.out.println(str);
		
	str=	str.toUpperCase();
	System.out.println(str);
	
	str=str.trim();
	System.out.println(str);
		
		

	}

}
