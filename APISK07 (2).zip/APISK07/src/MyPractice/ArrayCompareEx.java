package MyPractice;

import java.util.Arrays;

public class ArrayCompareEx {

	public static void main(String[] args) {
		
		int []a= {102,94,106,478,900};
		
		int []b= {102,34,56,78};
		
	int x=	Arrays.compare(a,b);
	
	System.out.println("Comparing two arrays  "+x);
	
	//Arrays.toString(a);
	
	
	
	System.out.println("After sorting elements are ");
	
	for(int y:b)
	{
		System.out.println(y);
	}
		
		

	}

}
