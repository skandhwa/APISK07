package MyPractice;

import java.util.Arrays;

public class ArrayEx2 {

	public static void main(String[] args) {
		
		
		int []a= {23,45,67,89};
		
		int []b= {0,23,45,67,89};
		
		int x=a.length;
		
		System.out.println("Length of array is  "+x);
		
		
	boolean flag=	Arrays.equals(a,b);
	
	System.out.println("Are two arrays equal "+flag);
		

	}

}
