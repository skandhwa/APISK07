package MyPractice;

public class ArrayEx1 {

	public static void main(String[] args) {
		
		int []a= {152,45,67,89,91};
		
		int []b=new int[] {15,72,67,18,62};
		
		for(int i=0;i<a.length;i++)///i=0,0<5 //i=1,1<5
		{
			System.out.println(a[i]);///a[0] //a[1]  //a[2]//a[3]//a[4]
		}
		
		System.out.println("Using For each loop");
		
		for(int x:b)
		{
			System.out.println(x);
		}
		
		
		
		

	}

}
