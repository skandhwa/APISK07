package MyPractice;

public class ArrayProgram1 {

	public static void main(String[] args) {
	
		int []a= {12,7,4,2};
		
		for(int i=0;i<a.length;i++)///i=1,1<4
		{
			for(int j=i+1;j<a.length;j++)///j=2,2<4
			{
				if(a[i]>a[j])///a[1]>a[2]
				{
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
					
				}
			}
			
			System.out.println(a[i]);
		}
		
		
		
		

	}

}
