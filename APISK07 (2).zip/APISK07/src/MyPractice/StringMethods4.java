package MyPractice;

public class StringMethods4 {

	public static void main(String[] args) {
		
		String str="Hello World";
		
		
		
	str=	str.replace("Hello", "Hi");
	
	
	str=str.replaceAll("H","h");
	
	
	System.out.println(str);
		
		
		
		

	}

}
