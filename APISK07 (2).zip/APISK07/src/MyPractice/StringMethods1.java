package MyPractice;

public class StringMethods1 {

	public static void main(String[] args) {
		
		
		String str="India";
//	char ch=	str.charAt(2);
//		System.out.println(ch);
		
		int x=str.length();
		
		System.out.println("The length is  "+x);
		
		
		

	}

}
