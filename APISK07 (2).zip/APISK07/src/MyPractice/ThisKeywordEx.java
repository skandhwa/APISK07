package MyPractice;

class Student
{
	int id;
	String name;
     String address; 
    
    Student(int id,String name,String address)
    {
    	this.id=id;
    	this.name=name;
    	this.address=address;
    }
    
     void display()
    {
    	System.out.println(id+"  "+name+"  "+address);
    }
    
    
    
}
public class ThisKeywordEx {

	public static void main(String[] args) {
		
		Student obj=new Student(1234,"Mohan","Delhi");
		obj.display();
		

	}

}
