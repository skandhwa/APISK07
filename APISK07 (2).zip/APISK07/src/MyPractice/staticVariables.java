package MyPractice;

class Test1
{
	static String str="Hello";
	
	
	

	
}



public class staticVariables {

	public static void main(String[] args) {
		
	System.out.println(Test1.str);	
		
		
		
		
		

	}

}
