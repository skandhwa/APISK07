package MyPractice;

class Test6
{
	final int speed=50;
	
	void display()
	{
		//speed=60;
		System.out.println("The speed of vehicle is  "+speed);
	}
}



public class FinalKeywordEx1 {

	public static void main(String[] args) {
		
		Test6 obj=new Test6();
		obj.display();
		
		
		
		

	}

}
