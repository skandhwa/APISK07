package MyPractice;

public class StringMethods6 {

	public static void main(String[] args) {
		
		String str="India is an independent country";
		
	String[]s1=	str.split(" ");
	
	String s2=s1[3].substring(2,4);
	System.out.println(s2);
		
	

	}

}
